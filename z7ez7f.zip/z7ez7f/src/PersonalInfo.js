import React, { Component } from "react";

class PersonalInfo extends Component {
  render() {
    return (
      <>
        <center>Personal Info: </center>
        <p>Name: Ferecov Eshqin </p>
        <p>Age: 21</p>
        <p>Address: Nariman Narimanov</p>
      </>
    );
  }
}

export default PersonalInfo;
