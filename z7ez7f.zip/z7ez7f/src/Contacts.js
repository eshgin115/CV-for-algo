import React, { Component } from "react";

class Contacts extends Component {
  render() {
    return (
      <>
        <center>Contacts: </center>
        <p>Phone: +994503105130</p>
        <p>Email: eshgin115@gmail.com</p>
        <p>Instagram: @private</p>
      </>
    );
  }
}

export default Contacts;
