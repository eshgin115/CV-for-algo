import React, { Component } from "react";
import ReactDOM from "react-dom";
import UserCV from "./UserCV";
import "./style.css";
const root = document.querySelector("#root");
ReactDOM.render(<UserCV />, root);
