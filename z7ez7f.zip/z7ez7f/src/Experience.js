import React, { Component } from "react";

class Experience extends Component {
  render() {
    return (
      <>
        <center>Experience: </center>
        <p>2021-2022 Mentor</p>
      </>
    );
  }
}

export default Experience;
